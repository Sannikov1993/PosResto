/**
 * PosLab Store - Общее хранилище данных для синхронизации между приложениями
 * Использует localStorage + BroadcastChannel API для мгновенной синхронизации
 */

const PosLabStore = {
    // Ключи хранилища
    KEYS: {
        ORDERS: 'poslab_orders',
        TABLES: 'poslab_tables',
        ZONES: 'poslab_zones',
        CATEGORIES: 'poslab_categories',
        DISHES: 'poslab_dishes',
        CUSTOMERS: 'poslab_customers',
        SHIFTS: 'poslab_shifts',
        SETTINGS: 'poslab_settings'
    },

    // BroadcastChannel для синхронизации между вкладками
    channel: null,
    listeners: {},
    orderCounter: null,

    // Инициализация
    init() {
        // Создаём канал для синхронизации
        if ('BroadcastChannel' in window) {
            this.channel = new BroadcastChannel('poslab_sync');
            this.channel.onmessage = (event) => {
                this._handleBroadcast(event.data);
            };
        }

        // Инициализируем счётчик заказов
        this.orderCounter = parseInt(localStorage.getItem('poslab_order_counter') || '100');

        // Инициализируем демо-данные если пусто
        if (!this.getOrders().length) {
            this._initDemoData();
        }

        console.log('[PosLabStore] Инициализирован');
        return this;
    },

    // === ЗАКАЗЫ ===

    getOrders() {
        try {
            return JSON.parse(localStorage.getItem(this.KEYS.ORDERS) || '[]');
        } catch { return []; }
    },

    getOrdersByStatus(status) {
        const orders = this.getOrders();
        if (status === 'active') {
            return orders.filter(o => ['new', 'cooking', 'ready', 'served'].includes(o.status));
        }
        return orders.filter(o => o.status === status);
    },

    getOrderById(id) {
        return this.getOrders().find(o => o.id === id);
    },

    createOrder(orderData) {
        const orders = this.getOrders();

        // Генерируем номер заказа
        this.orderCounter++;
        localStorage.setItem('poslab_order_counter', this.orderCounter.toString());

        const newOrder = {
            id: Date.now(),
            order_number: this.orderCounter,
            status: 'new',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            type: orderData.type || 'dine_in',
            table_id: orderData.table_id || null,
            table: orderData.table || this._getTableById(orderData.table_id),
            customer: orderData.customer || null,
            customer_id: orderData.customer_id || null,
            items: (orderData.items || []).map((item, index) => ({
                id: Date.now() + index,
                dish_id: item.dish_id,
                name: item.name,
                price: item.price,
                quantity: item.quantity,
                total: item.price * item.quantity,
                notes: item.notes || null
            })),
            total: orderData.total || orderData.items?.reduce((sum, i) => sum + i.price * i.quantity, 0) || 0,
            payment_status: 'pending',
            notes: orderData.notes || null
        };

        orders.unshift(newOrder);
        this._saveOrders(orders);

        // Обновляем статус стола
        if (newOrder.table_id) {
            this.updateTableStatus(newOrder.table_id, 'occupied');
        }

        // Оповещаем другие вкладки
        this._broadcast('order_created', newOrder);

        console.log('[PosLabStore] Создан заказ:', newOrder.order_number);
        return newOrder;
    },

    updateOrderStatus(orderId, newStatus) {
        const orders = this.getOrders();
        const order = orders.find(o => o.id === orderId);

        if (!order) return null;

        const oldStatus = order.status;
        order.status = newStatus;
        order.updated_at = new Date().toISOString();

        // Дополнительные поля по статусу
        if (newStatus === 'cooking') {
            order.cooking_started_at = new Date().toISOString();
        } else if (newStatus === 'ready') {
            order.ready_at = new Date().toISOString();
        } else if (newStatus === 'completed') {
            order.completed_at = new Date().toISOString();
            // Освобождаем стол
            if (order.table_id) {
                this.updateTableStatus(order.table_id, 'free');
            }
        }

        this._saveOrders(orders);

        // Оповещаем о смене статуса
        this._broadcast('order_status_changed', { order, oldStatus, newStatus });

        console.log(`[PosLabStore] Заказ #${order.order_number}: ${oldStatus} -> ${newStatus}`);
        return order;
    },

    // === СТОЛЫ ===

    getTables() {
        try {
            return JSON.parse(localStorage.getItem(this.KEYS.TABLES) || '[]');
        } catch { return []; }
    },

    getTablesByZone(zoneId) {
        return this.getTables().filter(t => t.zone_id === zoneId);
    },

    _getTableById(id) {
        return this.getTables().find(t => t.id === id) || null;
    },

    updateTableStatus(tableId, status) {
        const tables = this.getTables();
        const table = tables.find(t => t.id === tableId);
        if (table) {
            table.status = status;
            table.updated_at = new Date().toISOString();
            localStorage.setItem(this.KEYS.TABLES, JSON.stringify(tables));
            this._broadcast('table_updated', table);
        }
        return table;
    },

    // === ЗОНЫ ===

    getZones() {
        try {
            return JSON.parse(localStorage.getItem(this.KEYS.ZONES) || '[]');
        } catch { return []; }
    },

    // === МЕНЮ ===

    getCategories() {
        try {
            return JSON.parse(localStorage.getItem(this.KEYS.CATEGORIES) || '[]');
        } catch { return []; }
    },

    getDishes() {
        try {
            return JSON.parse(localStorage.getItem(this.KEYS.DISHES) || '[]');
        } catch { return []; }
    },

    getDishesByCategory(categoryId) {
        return this.getDishes().filter(d => d.category_id === categoryId);
    },

    // === ПОДПИСКИ НА СОБЫТИЯ ===

    on(event, callback) {
        if (!this.listeners[event]) {
            this.listeners[event] = [];
        }
        this.listeners[event].push(callback);
        return () => this.off(event, callback);
    },

    off(event, callback) {
        if (this.listeners[event]) {
            this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
        }
    },

    // === ПРИВАТНЫЕ МЕТОДЫ ===

    _saveOrders(orders) {
        localStorage.setItem(this.KEYS.ORDERS, JSON.stringify(orders));
    },

    _broadcast(type, data) {
        // Сериализуем данные для безопасной передачи через BroadcastChannel
        const safeData = JSON.parse(JSON.stringify(data));
        const message = { type, data: safeData, timestamp: Date.now() };

        // Локальные слушатели
        if (this.listeners[type]) {
            this.listeners[type].forEach(cb => {
                try {
                    cb(safeData);
                } catch (e) {
                    console.error('[PosLabStore] Ошибка в слушателе:', e);
                }
            });
        }

        // BroadcastChannel для других вкладок
        if (this.channel) {
            try {
                this.channel.postMessage(message);
            } catch (e) {
                console.error('[PosLabStore] Ошибка отправки в BroadcastChannel:', e);
            }
        }
    },

    _handleBroadcast(message) {
        console.log('[PosLabStore] Получено сообщение:', message.type);

        // Вызываем локальные слушатели
        if (this.listeners[message.type]) {
            this.listeners[message.type].forEach(cb => cb(message.data));
        }

        // Специальные события
        if (message.type === 'order_created') {
            if (this.listeners['new_order']) {
                this.listeners['new_order'].forEach(cb => cb(message.data));
            }
        }
    },

    _initDemoData() {
        console.log('[PosLabStore] Инициализация демо-данных...');

        // Зоны
        const zones = [
            { id: 1, name: 'Основной зал', color: '#10B981' },
            { id: 2, name: 'VIP зал', color: '#8B5CF6' },
            { id: 3, name: 'Терраса', color: '#F59E0B' }
        ];
        localStorage.setItem(this.KEYS.ZONES, JSON.stringify(zones));

        // Столы
        const tables = [
            { id: 1, zone_id: 1, number: '1', seats: 4, shape: 'square', position_x: 50, position_y: 50, width: 80, height: 80, status: 'free' },
            { id: 2, zone_id: 1, number: '2', seats: 4, shape: 'square', position_x: 150, position_y: 50, width: 80, height: 80, status: 'free' },
            { id: 3, zone_id: 1, number: '3', seats: 2, shape: 'round', position_x: 250, position_y: 50, width: 70, height: 70, status: 'free' },
            { id: 4, zone_id: 1, number: '4', seats: 6, shape: 'rectangle', position_x: 350, position_y: 50, width: 120, height: 80, status: 'free' },
            { id: 5, zone_id: 1, number: '5', seats: 4, shape: 'square', position_x: 50, position_y: 180, width: 80, height: 80, status: 'free' },
            { id: 6, zone_id: 1, number: '6', seats: 4, shape: 'square', position_x: 150, position_y: 180, width: 80, height: 80, status: 'free' },
            { id: 7, zone_id: 1, number: '7', seats: 8, shape: 'rectangle', position_x: 280, position_y: 180, width: 160, height: 90, status: 'free' },
            { id: 8, zone_id: 1, number: '8', seats: 2, shape: 'round', position_x: 50, position_y: 320, width: 60, height: 60, status: 'free' },
            { id: 9, zone_id: 1, number: '9', seats: 2, shape: 'round', position_x: 130, position_y: 320, width: 60, height: 60, status: 'free' },
            { id: 10, zone_id: 1, number: '10', seats: 4, shape: 'square', position_x: 220, position_y: 310, width: 80, height: 80, status: 'free' },
            { id: 13, zone_id: 2, number: 'V1', seats: 6, shape: 'round', position_x: 80, position_y: 80, width: 120, height: 120, status: 'free' },
            { id: 14, zone_id: 2, number: 'V2', seats: 8, shape: 'rectangle', position_x: 250, position_y: 60, width: 180, height: 100, status: 'free' },
            { id: 16, zone_id: 3, number: 'T1', seats: 2, shape: 'round', position_x: 40, position_y: 40, width: 60, height: 60, status: 'free' },
            { id: 17, zone_id: 3, number: 'T2', seats: 2, shape: 'round', position_x: 120, position_y: 40, width: 60, height: 60, status: 'free' },
            { id: 18, zone_id: 3, number: 'T3', seats: 4, shape: 'square', position_x: 200, position_y: 30, width: 80, height: 80, status: 'free' }
        ];
        localStorage.setItem(this.KEYS.TABLES, JSON.stringify(tables));

        // Категории меню
        const categories = [
            { id: 1, name: 'Пицца', icon: '🍕' },
            { id: 2, name: 'Бургеры', icon: '🍔' },
            { id: 3, name: 'Салаты', icon: '🥗' },
            { id: 4, name: 'Напитки', icon: '🥤' },
            { id: 5, name: 'Десерты', icon: '🍰' }
        ];
        localStorage.setItem(this.KEYS.CATEGORIES, JSON.stringify(categories));

        // Блюда
        const dishes = [
            { id: 1, category_id: 1, name: 'Маргарита', price: 450, is_available: true },
            { id: 2, category_id: 1, name: 'Пепперони', price: 550, is_available: true },
            { id: 3, category_id: 1, name: '4 сыра', price: 620, is_available: true },
            { id: 4, category_id: 1, name: 'Гавайская', price: 520, is_available: true },
            { id: 5, category_id: 2, name: 'Классик бургер', price: 320, is_available: true },
            { id: 6, category_id: 2, name: 'Чизбургер', price: 350, is_available: true },
            { id: 7, category_id: 2, name: 'Двойной бургер', price: 480, is_available: true },
            { id: 8, category_id: 2, name: 'Чикен бургер', price: 380, is_available: true },
            { id: 9, category_id: 3, name: 'Цезарь', price: 380, is_available: true },
            { id: 10, category_id: 3, name: 'Греческий', price: 320, is_available: true },
            { id: 11, category_id: 3, name: 'Овощной', price: 280, is_available: true },
            { id: 12, category_id: 4, name: 'Кола 0.5л', price: 120, is_available: true },
            { id: 13, category_id: 4, name: 'Сок апельсин', price: 150, is_available: true },
            { id: 14, category_id: 4, name: 'Чай', price: 100, is_available: true },
            { id: 15, category_id: 4, name: 'Кофе', price: 180, is_available: true },
            { id: 16, category_id: 5, name: 'Тирамису', price: 350, is_available: true },
            { id: 17, category_id: 5, name: 'Чизкейк', price: 320, is_available: true },
            { id: 18, category_id: 5, name: 'Мороженое', price: 200, is_available: true }
        ];
        localStorage.setItem(this.KEYS.DISHES, JSON.stringify(dishes));

        // Пустой список заказов
        localStorage.setItem(this.KEYS.ORDERS, JSON.stringify([]));
    },

    // Сброс всех данных (для отладки)
    reset() {
        Object.values(this.KEYS).forEach(key => localStorage.removeItem(key));
        localStorage.removeItem('poslab_order_counter');
        this._initDemoData();
        this._broadcast('data_reset', {});
        console.log('[PosLabStore] Данные сброшены');
    }
};

// Автоматическая инициализация
if (typeof window !== 'undefined') {
    window.PosLabStore = PosLabStore.init();
}
